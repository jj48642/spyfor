from .Format_Regression_Output import PrintRegressions
from .Stata_Reg_Obj import res_obj
